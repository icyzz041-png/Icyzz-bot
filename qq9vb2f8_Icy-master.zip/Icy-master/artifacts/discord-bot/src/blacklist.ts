import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, "..", "data", "blacklist.json");

export interface BlacklistEntry {
  userId: string;
  tag: string;
  reason: string;
  addedBy: string;
  addedAt: string;
}

function load(): Record<string, BlacklistEntry> {
  try {
    if (!fs.existsSync(DATA_FILE)) return {};
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
  } catch {
    return {};
  }
}

function save(data: Record<string, BlacklistEntry>) {
  const dir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

export function addToBlacklist(entry: BlacklistEntry): void {
  const data = load();
  data[entry.userId] = entry;
  save(data);
}

export function removeFromBlacklist(userId: string): BlacklistEntry | null {
  const data = load();
  const entry = data[userId] ?? null;
  if (!entry) return null;
  delete data[userId];
  save(data);
  return entry;
}

export function getBlacklistEntry(userId: string): BlacklistEntry | null {
  return load()[userId] ?? null;
}

export function getBlacklistCount(): number {
  return Object.keys(load()).length;
}
