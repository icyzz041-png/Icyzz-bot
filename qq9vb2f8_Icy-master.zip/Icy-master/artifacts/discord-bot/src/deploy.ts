import { REST, Routes, SlashCommandBuilder } from "discord.js";

const token = process.env.DISCORD_BOT_TOKEN;
if (!token) {
  throw new Error("DISCORD_BOT_TOKEN is required");
}

const commands = [
  new SlashCommandBuilder()
    .setName("check")
    .setDescription("Check if a Roblox user owns any of the shirts/items")
    .addStringOption((option) =>
      option
        .setName("username")
        .setDescription("The Roblox username to check")
        .setRequired(true)
    ),
].map((cmd) => cmd.toJSON());

const rest = new REST({ version: "10" }).setToken(token);

async function deploy() {
  try {
    const clientId = Buffer.from(token!.split(".")[0], "base64").toString("utf-8");
    console.log(`Deploying slash commands for client: ${clientId}`);

    await rest.put(Routes.applicationCommands(clientId), { body: commands });

    console.log("Successfully registered global slash commands.");
  } catch (err) {
    console.error("Failed to register commands:", err);
    process.exit(1);
  }
}

deploy();
