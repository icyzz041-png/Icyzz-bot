import {
  Client,
  GatewayIntentBits,
  ChatInputCommandInteraction,
  EmbedBuilder,
  Events,
  REST,
  Routes,
  SlashCommandBuilder,
  GuildMember,
  Message,
  TextChannel,
} from "discord.js";
import { getRobloxUserId, checkOwnership, ITEMS } from "./roblox.js";
import {
  addToBlacklist,
  removeFromBlacklist,
  getBlacklistEntry,
  getBlacklistCount,
} from "./blacklist.js";
import { getNextOrderId } from "./orders.js";

const token = process.env.DISCORD_BOT_TOKEN;
if (!token) {
  throw new Error("DISCORD_BOT_TOKEN environment variable is required");
}

const ORDER_CHANNEL_ID = "1477914091912954008";
const COMPLETED_CHANNEL_ID = "1481044879084621844";
const LOG_CHANNEL_ID = "1478010069290324153";
const VOUCH_CHANNEL_ID = "1477922599441797161";
const PING_USER_ID = "1252632005938516064";
const PING_ROLE_ID = "1477913965790105660";

const ALLOWED_ROLE_IDS = [
  "1477913973327134851",
  "1477913968243773571",
  "1477913965790105660",
  "1477913976288448725",
];

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

async function registerCommands() {
  const commands = [
    new SlashCommandBuilder()
      .setName("check")
      .setDescription("Check if a Roblox user owns any of the shirts/items")
      .addStringOption((option) =>
        option
          .setName("username")
          .setDescription("The Roblox username to check")
          .setRequired(true)
      ),
    new SlashCommandBuilder()
      .setName("order")
      .setDescription("Submit an order request")
      .addUserOption((opt) =>
        opt.setName("discord").setDescription("The customer's Discord account").setRequired(true)
      )
      .addStringOption((opt) =>
        opt.setName("order").setDescription("What is being ordered?").setRequired(true)
      )
      .addStringOption((opt) =>
        opt.setName("payment").setDescription("Payment method / amount").setRequired(true)
      )
      .addAttachmentOption((opt) =>
        opt.setName("proof").setDescription("Screenshot or proof of payment").setRequired(true)
      ),
    new SlashCommandBuilder()
      .setName("ordercompleted")
      .setDescription("Log a completed order")
      .addIntegerOption((opt) =>
        opt.setName("id").setDescription("The Order ID # from the order request (e.g. 12)").setRequired(true)
      )
      .addUserOption((opt) =>
        opt.setName("discord").setDescription("The customer's Discord account").setRequired(true)
      )
      .addStringOption((opt) =>
        opt.setName("order").setDescription("What was ordered?").setRequired(true)
      )
      .addStringOption((opt) =>
        opt.setName("payment").setDescription("Payment received").setRequired(true)
      )
      .addAttachmentOption((opt) =>
        opt.setName("proof").setDescription("Screenshot or proof of completion").setRequired(true)
      ),
    new SlashCommandBuilder()
      .setName("vieworders")
      .setDescription("View order requests and completed orders")
      .addUserOption((opt) =>
        opt.setName("user").setDescription("Filter orders by a specific user (optional)").setRequired(false)
      ),
    new SlashCommandBuilder()
      .setName("ordercancel")
      .setDescription("Cancel an order and log it")
      .addUserOption((opt) =>
        opt.setName("discord").setDescription("The customer's Discord account").setRequired(true)
      )
      .addStringOption((opt) =>
        opt.setName("order").setDescription("What was the order?").setRequired(true)
      )
      .addStringOption((opt) =>
        opt.setName("reason").setDescription("Reason for cancellation").setRequired(true)
      ),
    new SlashCommandBuilder()
      .setName("blacklist")
      .setDescription("Manage the blacklist")
      .addSubcommand((sub) =>
        sub
          .setName("add")
          .setDescription("Add a user to the blacklist")
          .addUserOption((opt) =>
            opt.setName("user").setDescription("User to blacklist").setRequired(true)
          )
          .addStringOption((opt) =>
            opt.setName("reason").setDescription("Reason for blacklisting").setRequired(true)
          )
      )
      .addSubcommand((sub) =>
        sub
          .setName("remove")
          .setDescription("Remove a user from the blacklist")
          .addUserOption((opt) =>
            opt.setName("user").setDescription("User to remove").setRequired(true)
          )
      ),
    new SlashCommandBuilder()
      .setName("blacklistcheck")
      .setDescription("Check if a user is blacklisted")
      .addUserOption((opt) =>
        opt.setName("user").setDescription("User to check").setRequired(true)
      ),
    new SlashCommandBuilder()
      .setName("stats")
      .setDescription("View server order statistics"),
    new SlashCommandBuilder()
      .setName("vouch")
      .setDescription("Leave a review for your order")
      .addStringOption((opt) =>
        opt
          .setName("rating")
          .setDescription("Your rating")
          .setRequired(true)
          .addChoices(
            { name: "⭐⭐⭐⭐⭐ — 5 stars", value: "5" },
            { name: "⭐⭐⭐⭐ — 4 stars", value: "4" },
            { name: "⭐⭐⭐ — 3 stars", value: "3" },
            { name: "⭐⭐ — 2 stars", value: "2" },
            { name: "⭐ — 1 star", value: "1" }
          )
      )
      .addStringOption((opt) =>
        opt.setName("review").setDescription("Your review / feedback").setRequired(true)
      )
      .addUserOption((opt) =>
        opt.setName("staff").setDescription("The staff member who helped you (optional)").setRequired(false)
      ),
  ].map((cmd) => cmd.toJSON());

  const rest = new REST({ version: "10" }).setToken(token!);
  const clientId = Buffer.from(token!.split(".")[0], "base64").toString("utf-8");

  await rest.put(Routes.applicationCommands(clientId), { body: commands });
  console.log("Slash commands registered globally.");
}

function hasAllowedRole(member: GuildMember): boolean {
  return ALLOWED_ROLE_IDS.some((roleId) => member.roles.cache.has(roleId));
}

async function logCommand(interaction: ChatInputCommandInteraction, details?: string) {
  try {
    const channel = await interaction.client.channels.fetch(LOG_CHANNEL_ID);
    if (!channel || !channel.isTextBased()) return;

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`📋 Command Used: /${interaction.commandName}`)
      .addFields(
        { name: "User", value: `<@${interaction.user.id}> (${interaction.user.tag})`, inline: true },
        { name: "Channel", value: `<#${interaction.channelId}>`, inline: true },
      )
      .setTimestamp();

    if (details) embed.addFields({ name: "Details", value: details });

    await channel.send({ embeds: [embed] });
  } catch (err) {
    console.error("Failed to log command:", err);
  }
}

async function handleCheck(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member || !hasAllowedRole(member)) {
    await interaction.reply({
      content: "❌ You do not have permission to use this command.",
      ephemeral: true,
    });
    return;
  }

  const username = interaction.options.getString("username", true).trim();

  await logCommand(interaction, `Checking: ${username}`);
  await interaction.deferReply();

  const userId = await getRobloxUserId(username);
  if (!userId) {
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xff4444)
          .setTitle("❌ User Not Found")
          .setDescription(`Could not find a Roblox user with the username **${username}**.`),
      ],
    });
    return;
  }

  const results = await Promise.all(
    ITEMS.map(async (item) => {
      const owned = await checkOwnership(userId, item.id);
      return { item, owned };
    })
  );

  const privateInventory = results.every((r) => r.owned === null);

  if (privateInventory) {
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xffaa00)
          .setTitle("🔒 Private Inventory")
          .setDescription(
            `**${username}**'s Roblox inventory is set to private. They need to make their inventory public for ownership to be verified.`
          ),
      ],
    });
    return;
  }

  const owned = results.filter((r) => r.owned === true);
  const notOwned = results.filter((r) => r.owned === false);

  const embed = new EmbedBuilder()
    .setTitle(`🔍 Ownership Check — ${username}`)
    .setTimestamp();

  if (owned.length > 0) {
    embed.setColor(0x00cc66);
    embed.addFields({
      name: "✅ Owns",
      value: owned.map((r) => `• **${r.item.name}** (${r.item.price})`).join("\n"),
    });
  }

  if (notOwned.length > 0) {
    embed.addFields({
      name: "❌ Does Not Own",
      value: notOwned.map((r) => `• **${r.item.name}** (${r.item.price})`).join("\n"),
    });
  }

  const profileLink = `[View Roblox Profile](https://www.roblox.com/users/${userId}/profile)`;

  if (owned.length === 0) {
    embed.setColor(0xff4444);
    embed.setDescription(`**${username}** does not own any of the items.\n${profileLink}`);
  } else {
    embed.setDescription(
      `**${username}** owns **${owned.length}** out of **${ITEMS.length}** items.\n${profileLink}`
    );
  }

  await interaction.editReply({ embeds: [embed] });
}

async function handleOrder(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member || !hasAllowedRole(member)) {
    await interaction.reply({
      content: "❌ You do not have permission to use this command.",
      ephemeral: true,
    });
    return;
  }

  const discordUser = interaction.options.getUser("discord", true);
  const order = interaction.options.getString("order", true);
  const payment = interaction.options.getString("payment", true);
  const proof = interaction.options.getAttachment("proof", true);

  await logCommand(interaction, `Customer: <@${discordUser.id}> | Order: ${order} | Payment: ${payment}`);

  const channel = await interaction.client.channels.fetch(ORDER_CHANNEL_ID);
  if (!channel || !channel.isTextBased()) {
    await interaction.reply({ content: "❌ Could not find the order channel.", ephemeral: true });
    return;
  }

  const orderId = getNextOrderId();

  const content = [
    `**Order ID:** #${orderId}`,
    `**Discord:** <@${discordUser.id}>`,
    `**Order:** ${order}`,
    `**Payment:** ${payment}`,
    `**Proof:** ${proof.url}`,
    ``,
    `<@${interaction.user.id}>`,
    `<@${PING_USER_ID}> <@&${PING_ROLE_ID}>`,
  ].join("\n");

  await channel.send({ content });

  await interaction.reply({ content: `✅ Order request sent! (Order ID: **#${orderId}**)`, ephemeral: true });
}

async function handleOrderCompleted(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member || !hasAllowedRole(member)) {
    await interaction.reply({
      content: "❌ You do not have permission to use this command.",
      ephemeral: true,
    });
    return;
  }

  const orderId = interaction.options.getInteger("id", true);
  const discordUser = interaction.options.getUser("discord", true);
  const order = interaction.options.getString("order", true);
  const payment = interaction.options.getString("payment", true);
  const proof = interaction.options.getAttachment("proof", true);

  await logCommand(interaction, `Order #${orderId} | Customer: <@${discordUser.id}> | Order: ${order} | Payment: ${payment}`);

  const channel = await interaction.client.channels.fetch(COMPLETED_CHANNEL_ID);
  if (!channel || !channel.isTextBased()) {
    await interaction.reply({ content: "❌ Could not find the completed orders channel.", ephemeral: true });
    return;
  }

  const content = [
    `**Order ID:** #${orderId} ✅`,
    `**Discord:** <@${discordUser.id}>`,
    `**Order:** ${order}`,
    `**Payment:** ${payment}`,
    `**Proof:** ${proof.url}`,
    ``,
    `<@${interaction.user.id}>`,
  ].join("\n");

  await channel.send({ content });

  await interaction.reply({ content: `✅ Order **#${orderId}** marked as completed and logged!`, ephemeral: true });
}

interface ParsedOrder {
  orderId: string;
  discord: string;
  order: string;
  payment: string;
  proof: string;
  submitter: string;
  timestamp: Date;
  messageUrl: string;
}

function parseOrderMessages(messages: Message[], filterUserId?: string): ParsedOrder[] {
  const results: ParsedOrder[] = [];

  for (const msg of messages) {
    const text = msg.content;

    const idMatch = text.match(/\*\*Order ID:\*\* #?(\d+)/);
    const discordMatch = text.match(/\*\*Discord:\*\* <@(\d+)>/);
    const orderMatch = text.match(/\*\*Order:\*\* (.+)/);
    const paymentMatch = text.match(/\*\*Payment:\*\* (.+)/);
    const proofMatch = text.match(/\*\*Proof:\*\* (.+)/);
    const submitterMatch = text.match(/\n<@(\d+)>\n/);

    if (!discordMatch || !orderMatch || !paymentMatch || !proofMatch) continue;

    const discordUserId = discordMatch[1];
    if (filterUserId && discordUserId !== filterUserId) continue;

    results.push({
      orderId: idMatch ? `#${idMatch[1]}` : "—",
      discord: `<@${discordUserId}>`,
      order: orderMatch[1].trim(),
      payment: paymentMatch[1].trim(),
      proof: proofMatch[1].trim(),
      submitter: submitterMatch ? `<@${submitterMatch[1]}>` : "Unknown",
      timestamp: msg.createdAt,
      messageUrl: msg.url,
    });
  }

  return results;
}

async function handleViewOrders(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;

  if (!member || !hasAllowedRole(member)) {
    await interaction.reply({
      content: "❌ You do not have permission to use this command.",
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply({ ephemeral: true });
  await logCommand(interaction);

  const filterUser = interaction.options.getUser("user");

  const [orderChannel, completedChannel] = await Promise.all([
    interaction.client.channels.fetch(ORDER_CHANNEL_ID),
    interaction.client.channels.fetch(COMPLETED_CHANNEL_ID),
  ]);

  const [orderMessages, completedMessages] = await Promise.all([
    orderChannel && orderChannel.isTextBased()
      ? (orderChannel as TextChannel).messages.fetch({ limit: 100 })
      : Promise.resolve(null),
    completedChannel && completedChannel.isTextBased()
      ? (completedChannel as TextChannel).messages.fetch({ limit: 100 })
      : Promise.resolve(null),
  ]);

  const botId = interaction.client.user!.id;

  const pendingOrders = orderMessages
    ? parseOrderMessages(
        [...orderMessages.values()].filter((m) => m.author.id === botId),
        filterUser?.id
      )
    : [];

  const completedOrders = completedMessages
    ? parseOrderMessages(
        [...completedMessages.values()].filter((m) => m.author.id === botId),
        filterUser?.id
      )
    : [];

  const filterLabel = filterUser ? ` for <@${filterUser.id}>` : "";

  const embeds: EmbedBuilder[] = [];

  const pendingEmbed = new EmbedBuilder()
    .setColor(0xffaa00)
    .setTitle(`📋 Order Requests${filterLabel}`)
    .setTimestamp();

  if (pendingOrders.length === 0) {
    pendingEmbed.setDescription("No order requests found.");
  } else {
    for (const o of pendingOrders.slice(0, 10)) {
      pendingEmbed.addFields({
        name: `${o.orderId} — ${o.discord} — ${o.order}`,
        value: `**Payment:** ${o.payment}\n**Staff:** ${o.submitter}\n**Proof:** [View](${o.proof})\n**Date:** <t:${Math.floor(o.timestamp.getTime() / 1000)}:R>`,
      });
    }
    if (pendingOrders.length > 10) {
      pendingEmbed.setFooter({ text: `Showing 10 of ${pendingOrders.length} orders` });
    }
  }

  const completedEmbed = new EmbedBuilder()
    .setColor(0x00cc66)
    .setTitle(`✅ Completed Orders${filterLabel}`)
    .setTimestamp();

  if (completedOrders.length === 0) {
    completedEmbed.setDescription("No completed orders found.");
  } else {
    for (const o of completedOrders.slice(0, 10)) {
      completedEmbed.addFields({
        name: `${o.orderId} — ${o.discord} — ${o.order}`,
        value: `**Payment:** ${o.payment}\n**Staff:** ${o.submitter}\n**Proof:** [View](${o.proof})\n**Date:** <t:${Math.floor(o.timestamp.getTime() / 1000)}:R>`,
      });
    }
    if (completedOrders.length > 10) {
      completedEmbed.setFooter({ text: `Showing 10 of ${completedOrders.length} orders` });
    }
  }

  embeds.push(pendingEmbed, completedEmbed);

  await interaction.editReply({ embeds });
}

async function handleVouch(interaction: ChatInputCommandInteraction) {
  const ratingStr = interaction.options.getString("rating", true);
  const review = interaction.options.getString("review", true);
  const staff = interaction.options.getUser("staff");
  const rating = parseInt(ratingStr, 10);
  const stars = "⭐".repeat(rating) + "✩".repeat(5 - rating);

  const vouchChannel = await interaction.client.channels.fetch(VOUCH_CHANNEL_ID);
  if (!vouchChannel || !vouchChannel.isTextBased()) {
    await interaction.reply({ content: "❌ Could not find the vouch channel.", ephemeral: true });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(rating >= 4 ? 0x00cc66 : rating === 3 ? 0xffaa00 : 0xff4444)
    .setTitle(`${stars} Review`)
    .setDescription(`> ${review}`)
    .addFields({ name: "Customer", value: `<@${interaction.user.id}>`, inline: true })
    .setTimestamp();

  if (staff) {
    embed.addFields({ name: "Staff", value: `<@${staff.id}>`, inline: true });
  }

  await vouchChannel.send({ embeds: [embed] });
  await logCommand(interaction, `Rating: ${rating}/5 | Review: ${review}${staff ? ` | Staff: <@${staff.id}>` : ""}`);
  await interaction.reply({ content: "✅ Your review has been posted. Thank you!", ephemeral: true });
}

async function handleOrderCancel(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;
  if (!member || !hasAllowedRole(member)) {
    await interaction.reply({ content: "❌ You do not have permission to use this command.", ephemeral: true });
    return;
  }

  const discordUser = interaction.options.getUser("discord", true);
  const order = interaction.options.getString("order", true);
  const reason = interaction.options.getString("reason", true);

  const logChannel = await interaction.client.channels.fetch(LOG_CHANNEL_ID);
  if (!logChannel || !logChannel.isTextBased()) {
    await interaction.reply({ content: "❌ Could not find the log channel.", ephemeral: true });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(0xff4444)
    .setTitle("🚫 Order Cancelled")
    .addFields(
      { name: "Discord", value: `<@${discordUser.id}>`, inline: true },
      { name: "Order", value: order, inline: true },
      { name: "Reason", value: reason },
      { name: "Cancelled By", value: `<@${interaction.user.id}>`, inline: true }
    )
    .setTimestamp();

  await logChannel.send({ embeds: [embed] });
  await logCommand(interaction, `Customer: <@${discordUser.id}> | Order: ${order} | Reason: ${reason}`);
  await interaction.reply({ content: "✅ Order cancelled and logged.", ephemeral: true });
}

async function handleBlacklist(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;
  if (!member || !hasAllowedRole(member)) {
    await interaction.reply({ content: "❌ You do not have permission to use this command.", ephemeral: true });
    return;
  }

  const sub = interaction.options.getSubcommand();
  const targetUser = interaction.options.getUser("user", true);
  const logChannel = await interaction.client.channels.fetch(LOG_CHANNEL_ID);

  if (sub === "add") {
    const reason = interaction.options.getString("reason", true);

    addToBlacklist({
      userId: targetUser.id,
      tag: targetUser.tag,
      reason,
      addedBy: interaction.user.tag,
      addedAt: new Date().toISOString(),
    });

    const embed = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle("🔨 User Blacklisted")
      .addFields(
        { name: "User", value: `<@${targetUser.id}> (${targetUser.tag})`, inline: true },
        { name: "Reason", value: reason },
        { name: "Added By", value: `<@${interaction.user.id}>`, inline: true }
      )
      .setTimestamp();

    if (logChannel?.isTextBased()) await logChannel.send({ embeds: [embed] });
    await logCommand(interaction, `Added: <@${targetUser.id}> | Reason: ${reason}`);
    await interaction.reply({ content: `✅ <@${targetUser.id}> has been blacklisted.`, ephemeral: true });

  } else if (sub === "remove") {
    const entry = removeFromBlacklist(targetUser.id);

    if (!entry) {
      await interaction.reply({ content: `⚠️ <@${targetUser.id}> is not on the blacklist.`, ephemeral: true });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(0x00cc66)
      .setTitle("✅ User Removed from Blacklist")
      .addFields(
        { name: "User", value: `<@${targetUser.id}> (${targetUser.tag})`, inline: true },
        { name: "Original Reason", value: entry.reason },
        { name: "Removed By", value: `<@${interaction.user.id}>`, inline: true }
      )
      .setTimestamp();

    if (logChannel?.isTextBased()) await logChannel.send({ embeds: [embed] });
    await logCommand(interaction, `Removed: <@${targetUser.id}>`);
    await interaction.reply({ content: `✅ <@${targetUser.id}> has been removed from the blacklist.`, ephemeral: true });
  }
}

async function handleBlacklistCheck(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;
  if (!member || !hasAllowedRole(member)) {
    await interaction.reply({ content: "❌ You do not have permission to use this command.", ephemeral: true });
    return;
  }

  const targetUser = interaction.options.getUser("user", true);
  const entry = getBlacklistEntry(targetUser.id);

  if (!entry) {
    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x00cc66)
          .setTitle("✅ Not Blacklisted")
          .setDescription(`<@${targetUser.id}> is **not** on the blacklist.`)
          .setTimestamp(),
      ],
      ephemeral: true,
    });
    return;
  }

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle("🚫 User is Blacklisted")
        .addFields(
          { name: "User", value: `<@${entry.userId}> (${entry.tag})`, inline: true },
          { name: "Reason", value: entry.reason },
          { name: "Blacklisted By", value: entry.addedBy, inline: true },
          { name: "Date", value: `<t:${Math.floor(new Date(entry.addedAt).getTime() / 1000)}:R>`, inline: true }
        )
        .setTimestamp(),
    ],
    ephemeral: true,
  });
}

async function handleStats(interaction: ChatInputCommandInteraction) {
  const member = interaction.member as GuildMember;
  if (!member || !hasAllowedRole(member)) {
    await interaction.reply({ content: "❌ You do not have permission to use this command.", ephemeral: true });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  const [orderChannel, completedChannel] = await Promise.all([
    interaction.client.channels.fetch(ORDER_CHANNEL_ID),
    interaction.client.channels.fetch(COMPLETED_CHANNEL_ID),
  ]);

  const botId = interaction.client.user!.id;

  const [orderMsgs, completedMsgs] = await Promise.all([
    orderChannel?.isTextBased()
      ? (orderChannel as TextChannel).messages.fetch({ limit: 100 })
      : Promise.resolve(null),
    completedChannel?.isTextBased()
      ? (completedChannel as TextChannel).messages.fetch({ limit: 100 })
      : Promise.resolve(null),
  ]);

  const totalOrders = orderMsgs ? [...orderMsgs.values()].filter((m) => m.author.id === botId).length : 0;
  const totalCompleted = completedMsgs ? [...completedMsgs.values()].filter((m) => m.author.id === botId).length : 0;
  const totalBlacklisted = getBlacklistCount();

  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle("📊 Server Stats")
    .addFields(
      { name: "📋 Order Requests", value: `${totalOrders}`, inline: true },
      { name: "✅ Completed Orders", value: `${totalCompleted}`, inline: true },
      { name: "🚫 Blacklisted Users", value: `${totalBlacklisted}`, inline: true }
    )
    .setFooter({ text: "Based on last 100 messages in each channel" })
    .setTimestamp();

  await logCommand(interaction);
  await interaction.editReply({ embeds: [embed] });
}

client.once(Events.ClientReady, async (c) => {
  console.log(`✅ Logged in as ${c.user.tag}`);
  try {
    await registerCommands();
  } catch (err) {
    console.error("Failed to register commands:", err);
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === "check") {
      try {
        await handleCheck(interaction);
      } catch (err) {
        console.error("Error handling /check:", err);
        const msg = { content: "An error occurred while checking ownership. Please try again." };
        if (interaction.deferred) {
          await interaction.editReply(msg);
        } else {
          await interaction.reply({ ...msg, ephemeral: true });
        }
      }
    }

    if (interaction.commandName === "order") {
      try {
        await handleOrder(interaction);
      } catch (err) {
        console.error("Error handling /order:", err);
        await interaction.reply({
          content: "An error occurred. Please try again.",
          ephemeral: true,
        });
      }
    }

    if (interaction.commandName === "ordercompleted") {
      try {
        await handleOrderCompleted(interaction);
      } catch (err) {
        console.error("Error handling /ordercompleted:", err);
        await interaction.reply({
          content: "An error occurred. Please try again.",
          ephemeral: true,
        });
      }
    }

    if (interaction.commandName === "vieworders") {
      try {
        await handleViewOrders(interaction);
      } catch (err) {
        console.error("Error handling /vieworders:", err);
        const msg = { content: "An error occurred while fetching orders. Please try again." };
        if (interaction.deferred) {
          await interaction.editReply(msg);
        } else {
          await interaction.reply({ ...msg, ephemeral: true });
        }
      }
    }

    if (interaction.commandName === "ordercancel") {
      try {
        await handleOrderCancel(interaction);
      } catch (err) {
        console.error("Error handling /ordercancel:", err);
        await interaction.reply({ content: "An error occurred. Please try again.", ephemeral: true });
      }
    }

    if (interaction.commandName === "blacklist") {
      try {
        await handleBlacklist(interaction);
      } catch (err) {
        console.error("Error handling /blacklist:", err);
        await interaction.reply({ content: "An error occurred. Please try again.", ephemeral: true });
      }
    }

    if (interaction.commandName === "blacklistcheck") {
      try {
        await handleBlacklistCheck(interaction);
      } catch (err) {
        console.error("Error handling /blacklistcheck:", err);
        await interaction.reply({ content: "An error occurred. Please try again.", ephemeral: true });
      }
    }

    if (interaction.commandName === "stats") {
      try {
        await handleStats(interaction);
      } catch (err) {
        console.error("Error handling /stats:", err);
        const msg = { content: "An error occurred while fetching stats. Please try again." };
        if (interaction.deferred) {
          await interaction.editReply(msg);
        } else {
          await interaction.reply({ ...msg, ephemeral: true });
        }
      }
    }

    if (interaction.commandName === "vouch") {
      try {
        await handleVouch(interaction);
      } catch (err) {
        console.error("Error handling /vouch:", err);
        await interaction.reply({ content: "An error occurred. Please try again.", ephemeral: true });
      }
    }
  }

});

client.login(token);
