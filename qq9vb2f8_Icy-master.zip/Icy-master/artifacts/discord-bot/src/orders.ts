import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, "..", "data", "orders.json");
 
interface OrdersData {
  counter: number;
}

function load(): OrdersData {
  try {
    if (!fs.existsSync(DATA_FILE)) return { counter: 0 };
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
  } catch {
    return { counter: 0 };
  }
}

function save(data: OrdersData) {
  const dir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

export function getNextOrderId(): number {
  const data = load();
  data.counter += 1;
  save(data);
  return data.counter;
}
