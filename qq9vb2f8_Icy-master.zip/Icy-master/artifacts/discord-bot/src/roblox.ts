export interface RobloxItem {
  id: string;
  name: string;
  price: string;
  url: string;
}

export const ITEMS: RobloxItem[] = [
  {
    id: "107003261130082",
    name: "1 Shirt or Pants",
    price: "100 rbx",
    url: "https://www.roblox.com/catalog/107003261130082",
  },
  {
    id: "109314462853156",
    name: "Bundle (Shirt & Pants)",
    price: "150 rbx",
    url: "https://www.roblox.com/catalog/109314462853156",
  },
  {
    id: "109620413094610",
    name: "Full Price",
    price: "200 rbx",
    url: "https://www.roblox.com/catalog/109620413094610",
  },
  {
    id: "120896738465879",
    name: "Tipper",
    price: "10 rbx tip",
    url: "https://www.roblox.com/catalog/120896738465879",
  },
  {
    id: "112873598869417",
    name: "Big Tipper",
    price: "50 rbx tip",
    url: "https://www.roblox.com/catalog/112873598869417",
  },
  {
    id: "114490166230849",
    name: "VIP Tipper",
    price: "100 rbx tip",
    url: "https://www.roblox.com/catalog/114490166230849",
  },
];

export async function getRobloxUserId(username: string): Promise<number | null> {
  const res = await fetch("https://users.roblox.com/v1/usernames/users", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }),
  });

  if (!res.ok) return null;

  const data = (await res.json()) as { data: { id: number; name: string }[] };
  if (!data.data || data.data.length === 0) return null;

  return data.data[0].id;
}

export async function checkOwnership(userId: number, itemId: string): Promise<boolean | null> {
  const res = await fetch(
    `https://inventory.roblox.com/v1/users/${userId}/items/Asset/${itemId}/is-owned`
  );

  if (res.status === 403) return null;
  if (!res.ok) return false;

  const owned = (await res.json()) as boolean;
  return owned;
}
